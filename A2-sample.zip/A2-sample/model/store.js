var mongoose = require('mongoose');

// Doc for Mongoose Schemas: http://mongoosejs.com/docs/guide
var Schema = mongoose.Schema;

/**
 * Note that the database was loaded with data from a JSON file into a
 * collection called gillers.
 */

var storeSchema = new Schema(
    {
        "storename": {type: String, required: true},
        "category": {type: String, default: ""},
        "address": {type: String, default: ""}
    }
);


// Doc for Mongoose Models: http://mongoosejs.com/docs/models
module.exports = mongoose.model('Stores', storeSchema);