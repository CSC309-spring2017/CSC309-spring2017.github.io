var mongoose = require('mongoose');

// Doc for Mongoose Schemas: http://mongoosejs.com/docs/guide
var Schema = mongoose.Schema;

/**
 * Note that the database was loaded with data from a JSON file into a
 * collection called gillers.
 */

var userSchema = new Schema(
    {
        "username": {type: String, required: true, unique: true},
        "firstname": {type: String, default: ""},
        "lastname": {type: String, default: ""},
        "sex": {type: String, default: ""},
        "age": {type: Number, default: 0}
    }
);


// Doc for Mongoose Models: http://mongoosejs.com/docs/models
module.exports = mongoose.model('Users', userSchema);