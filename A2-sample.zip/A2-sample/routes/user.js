var express = require('express');
var router = express.Router();
var User = require('../model/user');
var Review = require('../model/review');

router.post('/', function (req, res) {
    if (req.body.username === undefined || req.body.username == "") {
        res.status(403).send("No Username Provided");
        return;
    }
    if (req.body.age !== undefined) {
        if (!isNaN(parseFloat(req.body.age))){
            req.body.age = parseFloat(req.body.age);
        }else{
            res.status(403).send("Invalid age");
            return;
        }
    }
    if ("_id" in req.body) {
        delete req.body._id;
    }
    User.findOne({username: req.body.username}).exec(function (err, data) {
        if (data == undefined) {
            User.create(req.body, function (err, user) {
                res.send(user);
            })
        } else {
            res.status(403).send("User already exist");
        }
    });
});

router.get('/', function (req, res) {
    var callback = function (err, data) {
        if (data == undefined) {
            res.status(404).send("User not found");
        } else {
            res.send(data);
        }
    };
    //Could simply to User.findOne(req.query) for shorther code but better convention to find by id if you're finding by id
    if (req.query.id) {
        User.findById(req.query.id).exec(callback);
    } else {
        User.findOne({username: req.query.username}).exec(callback);
    }
});

router.delete('/', function (req, res) {
    User.findByIdAndRemove(req.query.id).exec(function (err, data) {
        if (data == undefined) {
            res.status(404).send("User not found");
        } else {
            Review.remove({userID: req.query.id}, function (err, reviews) {
                res.send(data);
            });
        }
    });
});
router.put('/', function (req, res) {
    if ("username" in req.body) {
        delete req.body.username;
    }
    if ("_id" in req.body) {
        delete req.body._id;
    }
    if (req.body.age !== undefined) {
        if (!isNaN(parseFloat(req.body.age))){
            req.body.age = parseFloat(req.body.age);
        }else{
            res.status(403).send("Invalid age");
            return;
        }
    }
    User.findByIdAndUpdate(req.query.id, req.body, {new: true}).exec(function (err, data) {
        if (data == undefined) {
            res.status(404).send("User not found");
        } else {
            res.send(data);
        }
    });
});
module.exports = router;
