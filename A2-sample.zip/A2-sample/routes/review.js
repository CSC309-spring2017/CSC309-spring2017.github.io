var express = require('express');
var router = express.Router();
var Review = require('../model/review');
var User = require('../model/user');
var Store = require('../model/store');
router.post('/', function (req, res) {
    if (req.body.userID === undefined
        || req.body.storeID === undefined) {
        res.status(403).send("Invalid Review");
        return;
    }

    // mpromise current has bugs with chaining, so we'll stick with no promises
    // normally, you should inject your own promise library to mongoose in order to chain promises

    Review.findOne({userID: req.body.userID, storeID: req.body.storeID}).exec(function (err, data) {
        if (data == undefined) {
            User.findById(req.body.userID).exec(function (err, user) {
                if (user == undefined) {
                    res.status(403).send("User doesn't exist");
                } else {
                    Store.findById(req.body.storeID).exec(function (err, store) {
                        if (store == undefined) {
                            res.status(403).send("Store doesn't exist");
                        } else {
                            if (req.body.rating !== undefined) {
                                if (validRating(req)) {
                                    req.body.rating = parseFloat(req.body.rating);
                                } else {
                                    res.status(403).send("Invalid rating");
                                    return;
                                }
                            }
                            // Notice with the current solution, we have a risk of making a review at the same moment a user/store is being deleted while this review is being committed,
                            // but for this assignment, we'll not be testing for handling such race condition
                            // If you want to learn more on how to handle atomicity in mongodb: https://docs.mongodb.com/manual/tutorial/perform-two-phase-commits/
                            Review.create(req.body, function (err, review) {
                                res.send(review);
                            });
                        }
                    });
                }
            })
        } else {
            res.status(403).send("Review already exist");
        }
    });
});

router.get('/', function (req, res) {
    if ("id" in req.query) {
        Review.findById(req.query.id).exec(function (err, data) {
            if (data == undefined) {
                res.status(404).send("Review not found");
            } else {
                res.send(data);
            }
        });
    } else if ("storeid" in req.query) {
        Review.find({storeID: req.query.storeid}).sort([['rating', 1], ['_id', 1]]).exec(function (err, data) {
            res.send({"reviews": data});
        });
    } else if ("userid" in req.query) {
        Review.find({userID: req.query.userid}).sort([['rating', 1], ['_id', 1]]).exec(function (err, data) {
            res.send({"reviews": data});
        });
    }

});

router.delete('/', function (req, res) {
    if ("id" in req.query) {
        Review.findByIdAndRemove(req.query.id).exec(function (err, data) {
            if (data == undefined) {
                res.status(404).send("Review not found");
            } else {
                res.send(data);
            }
        });
    } else if ("storeid" in req.query) {
        Store.findById(req.query.storeid).exec(function (err, store) {
            if (store == undefined) {
                res.send.status(404).send("Store doesn't exist");
            } else {
                Review.remove({storeID: req.query.storeid}).exec(function (err, data) {
                    res.send({"reviews": data});
                });
            }
        });

    } else if ("userid" in req.query) {
        User.findById(req.query.userid).exec(function (err, user) {
            if (user == undefined) {
                res.status(404).send("User doesn't exist");
            } else {
                Review.remove({userID: req.query.userid}).exec(function (err, data) {
                    res.send({"reviews": data});
                });
            }
        });
    }
});

function validRating(req) {
    return !(
    isNaN(parseFloat(req.body.rating))
    || parseFloat(req.body.rating) > 10
    || parseFloat(req.body.rating) < 0);
}

router.put('/', function (req, res) {
    if (req.body.rating !== undefined) {
        if (validRating(req)) {
            req.body.rating = parseFloat(req.body.rating);
        } else {
            res.status(403).send("Invalid rating");
            return;
        }
    }
    var toUpdate = {};
    if ("rating" in req.body) {
        toUpdate["rating"] = req.body.rating;
    }
    if ("comment" in req.body) {
        toUpdate["comment"] = req.body.comment;
    }


    Review.findByIdAndUpdate(req.query.id, toUpdate, {new: true}).exec(function (err, data) {
        if (data == undefined) {
            res.status(404).send("Review not found");
        } else {
            res.send(data);
        }
    });
})
;
module.exports = router;
