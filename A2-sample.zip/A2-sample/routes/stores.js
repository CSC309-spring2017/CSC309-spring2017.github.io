var express = require('express');
var router = express.Router();
var Store = require('../model/store');

router.get('/', function (req, res) {
    Store.find(req.query).sort([['storename', 1], ['_id', 1]]).exec(function (err, data) {
        res.send({stores: data});
    });
});
module.exports = router;
