var express = require('express');
var router = express.Router();
var User = require('../model/user');

router.get('/', function (req, res) {
    User.find(req.query).sort({username: 1}).exec(function (err, data) {
        res.send({users: data});
    });
});
module.exports = router;
