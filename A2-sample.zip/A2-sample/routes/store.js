var express = require('express');
var router = express.Router();
var Store = require('../model/store');
var Review = require('../model/review');
router.post('/', function (req, res) {
    if ("_id" in req.body) {
        delete req.body._id;
    }
    if (req.body.storename === undefined || req.body.storename == "") {
        res.status(403).send("No storename Provided");
        return;
    }
    Store.create(req.body, function (err, store) {
        res.send(store);
    });
});

router.get('/', function (req, res) {
    Store.findById(req.query.id).exec(function (err, data) {
        if (data == undefined) {
            res.status(404).send("Store not found");
        } else {
            res.send(data);
        }
    });
});

router.delete('/', function (req, res) {
    Store.findByIdAndRemove(req.query.id).exec(function (err, data) {
        if (data == undefined) {
            res.status(404).send("Store not found");
        } else {
            Review.remove({storeID: req.query.id}, function (err, reviews) {
                res.send(data);
            });
        }
    });
});
router.put('/', function (req, res) {
    if ("_id" in req.body) {
        delete req.body._id;
    }
    if (req.body.storename == "") {
        res.status(403).send("Storename cannot be empty");
        return;
    }
    Store.findByIdAndUpdate(req.query.id, req.body, {new: true}).exec(function (err, data) {
        if (data == undefined) {
            res.status(404).send("Store not found");
        } else {
            res.send(data);
        }
    });
});
module.exports = router;
